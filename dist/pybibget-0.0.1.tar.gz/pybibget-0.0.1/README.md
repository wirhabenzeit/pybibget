# pybibget
Python Module to automatically retrieve BibTeX citations from MathSciNet, arXiv and Pubmed
